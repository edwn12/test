import Collection from "../utils/Collection";

const ServiceData = [
  { id: 1, title: "Payroll", icon: Collection.Payroll },
  { id: 2, title: "History", icon: Collection.History },
  { id: 3, title: "Ticketing", icon: Collection.Ticketing },
  { id: 4, title: "Poliklinik", icon: Collection.Poliklinik },
  { id: 5, title: "Pendidikan", icon: Collection.Payroll },
  { id: 6, title: "Keuangan", icon: Collection.Payroll },
  { id: 7, title: "SDM", icon: Collection.Payroll },
  { id: 8, title: "Sarana Prasarana", icon: Collection.Payroll },
  { id: 9, title: "Pengembangan Strategis", icon: Collection.Payroll },
  { id: 10, title: "SIM", icon: Collection.Payroll },
  { id: 11, title: "Biro", icon: Collection.Payroll },
];
export default ServiceData;
