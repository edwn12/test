export default {
  "Poppins-Regular": "Poppins-Regular",
  "Poppins-Medium": "Poppins-Medium",
  "Poppins-Bold": "Poppins-Bold",
};
