export default {
  Primary: "#5572B7",

  Black: "#000",

  White: "#FFF",

  Grey: "#EDEDED",

  GreyText: "#9a9a9a",

  Yellow: "#FFDF28",

  subYellow: "#FFCB31",

  Blue: "#2A65FF",

  Red: "#FF5454",

  Green: "#19A337",

  Pink: "#FF008A",

  //Profile
  label_profile: "#666",
  value_profile: "#333",
  eror_profile: "#FF5454",
};
