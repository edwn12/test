// import { BASE_URL, LOGIN_URL, ATTENDANCE_URL } from "@env";

export const BASE_ENDPOINT = "https://devbpkpenaburjakarta.my.id/";
export const LOGIN_ENDPOINT = "api_Login/Login.php";
export const ATTENDANCE_ENDPOINT = "api_Login/Absen.php";
export const PERMIT_ENDPOINT = "api_Login/Izin.php";

