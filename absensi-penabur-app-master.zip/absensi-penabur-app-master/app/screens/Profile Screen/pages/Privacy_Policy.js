import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

import styles from '../css/PrivacyPolicyStyles'

const Privacy_Policy = () => {
  return (
    <View>
      <Text>Privacy_Policy</Text>
    </View>
  )
}

export default Privacy_Policy
