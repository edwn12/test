import { Text, View } from 'react-native'
import React from 'react'

import styles from '../css/SecurityStyles'

const Security = () => {
  return (
    <View>
      <Text>Security</Text>
    </View>
  )
}

export default Security
