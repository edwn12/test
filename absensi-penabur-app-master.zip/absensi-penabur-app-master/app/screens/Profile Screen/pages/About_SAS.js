import { Text, View } from "react-native";
import React from "react";

import styles from "../css/AboutSASStyles";

const About_SAS = () => {
  return (
    <View>
    </View>
  );
};

export default About_SAS;

